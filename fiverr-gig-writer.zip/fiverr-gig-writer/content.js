(() => {
if (window.__fgwLoaded) return;
window.__fgwLoaded = true;
// Runs on fiverr.com. Fiverr's markup changes often, so everything is located
// by labels/placeholders/roles rather than fixed selectors. Best-effort.
const rnd = () => String(Math.random()).slice(2);
const sleep = ms => new Promise(r => setTimeout(r, ms));
const visible = el => !!(el.offsetParent || el.getClientRects().length);
function labelText(el) {
  const out = [];
  if (el.labels) for (const l of el.labels) out.push(l.innerText);
  const lb = el.getAttribute && el.getAttribute("aria-labelledby");
  if (lb) lb.split(" ").forEach(id => out.push(document.getElementById(id)?.innerText || ""));
  let n = el;
  for (let i = 0; i < 4 && n.parentElement; i++) {          // nearest container with a short caption
    n = n.parentElement;
    const t = (n.innerText || "").trim();
    if (t && t.length < 150 && t !== (el.value || "")) { out.push(t.split("\n")[0]); break; }
  }
  return out.join(" ");
}
const hint = el => [el.name, el.id, el.placeholder, el.getAttribute("aria-label"), el.getAttribute("data-testid"), labelText(el)].join(" ").toLowerCase();
const all = (sel, re) => [...document.querySelectorAll(sel)].filter(el => visible(el) && (!re || re.test(hint(el))));
const rowText = el => { let n = el; for (let i = 0; i < 5 && n; i++, n = n.parentElement) if ((n.innerText || "").length > 3 && i >= 1) return (n.innerText || "").slice(0, 200).toLowerCase(); return ""; };

function setValue(el, value) {
  if (el.isContentEditable) { el.focus(); document.execCommand("selectAll", false); document.execCommand("insertText", false, value); return; }
  const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : el.tagName === "SELECT" ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
  Object.getOwnPropertyDescriptor(proto, "value").set.call(el, value);
  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
}
const key = (el, k, code) => ["keydown", "keyup"].forEach(t => el.dispatchEvent(new KeyboardEvent(t, { key: k, code: k, keyCode: code, bubbles: true })));
const click = el => {                         // a real-looking click: pointer + mouse events with coordinates
  const r = el.getBoundingClientRect();
  const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2, button: 0 };
  try { el.focus?.({ preventScroll: true }); } catch {}
  for (const t of ["pointerdown", "mousedown", "pointerup", "mouseup", "click"])
    el.dispatchEvent(t.startsWith("pointer") ? new PointerEvent(t, { ...o, pointerType: "mouse", isPrimary: true }) : new MouseEvent(t, o));
};

let KNOWN = new Set();                         // normalised names of every Fiverr category / subcategory / service type
const normK = s => String(s || "").toLowerCase().replace(/\s+/g, " ").trim();
const COMBO = '[role=combobox],[aria-haspopup=listbox],select';
const optionEls = () => all('[role=option],[role=listbox] li,li[class*=option i],div[class*=option i]');

function dropdownOptions(el) {
  if (el.tagName === "SELECT") return [...el.options].filter(o => o.value && !/^select/i.test(o.text)).map(o => o.text.trim());
  return [...new Set(optionEls().map(o => o.innerText.trim()).filter(Boolean))];
}
const leafish = () => [...document.querySelectorAll("li,div,span,a,button,p,label")].filter(e => {
  if (!visible(e) || e.children.length > 2) return false;
  const t = (e.innerText || "").trim(); return t.length > 0 && t.length < 70;
});
// Opens a dropdown and returns its option texts. Custom dropdowns with no ARIA roles are detected
// by diffing which elements appeared after the click, and those are tagged data-fgw-opt.
const closeMenu = el => { key(el, "Escape", 27); document.body.click(); };
const innermost = list => list.filter(e => !list.some(o => o !== e && e.contains(o)));   // drop wrappers that merely contain another match
const knownLeaves = () => leafish().filter(e => KNOWN.has(normK(e.innerText)));

// Opens a dropdown and returns its option texts. With the known-names list, options are recognised by their text
// (independent of Fiverr's markup); several ways of opening the menu are tried.
async function openOptions(el) {
  if (el.tagName === "SELECT") return dropdownOptions(el);
  document.querySelectorAll("[data-fgw-opt]").forEach(e => delete e.dataset.fgwOpt);
  if (KNOWN.size) {
    const targets = [el, el.firstElementChild, el.lastElementChild, ...[...el.querySelectorAll("button,[role=button],svg")].slice(0, 3), el.parentElement].filter((t, i, a) => t && a.indexOf(t) === i);
    for (const how of [...targets, "keyboard"]) {
      const before = new Set(knownLeaves());
      if (how === "keyboard") { el.focus?.(); key(el, "ArrowDown", 40); key(el, "Enter", 13); } else click(how);
      await sleep(450);
      const fresh = innermost(knownLeaves().filter(e => !before.has(e)));
      if (fresh.length >= 1) { fresh.forEach(e => e.dataset.fgwOpt = "1"); return [...new Set(fresh.map(e => e.innerText.trim()))]; }
      closeMenu(el); await sleep(150);
    }
    return [];
  }
  const before = new Set(leafish());
  const read = () => {
    const roled = optionEls();
    if (roled.length) return roled.map(o => o.innerText.trim());
    const fresh = leafish().filter(e => !before.has(e));
    fresh.forEach(e => e.dataset.fgwOpt = "1");
    return fresh.map(e => e.innerText.trim());
  };
  click(el); await sleep(500);
  let texts = read();
  if (!texts.length && el.firstElementChild) { click(el.firstElementChild); await sleep(450); texts = read(); }
  return [...new Set(texts.filter(t => t && !t.includes("\n") && !/^\s*(select|choose)\b/i.test(t)))];
}
async function choose(el, matcher) {           // matcher: string or RegExp
  const ok = t => matcher instanceof RegExp ? matcher.test(t) : normK(t) === normK(matcher);
  if (el.tagName === "SELECT") {
    const o = [...el.options].find(o => ok(o.text)); if (!o) return false;
    setValue(el, o.value); return true;
  }
  const find = () => {
    let l = optionEls();
    if (!l.length) l = [...document.querySelectorAll("[data-fgw-opt]")].filter(visible);
    if (!l.length && KNOWN.size) l = knownLeaves();
    return innermost(l.filter(o => ok(o.innerText)))[0];
  };
  let o = find();
  if (!o) { await openOptions(el); o = find(); }
  if (!o) return false;
  const picked = typeof matcher === "string" ? normK(matcher) : null;
  const done = () => !document.contains(o) || !visible(o) || (picked && normK(el.innerText).includes(picked));
  for (const how of [() => click(o), () => o.click(), () => o.parentElement && click(o.parentElement), () => { key(o, "Enter", 13); }]) {
    how(); await sleep(300);
    if (done()) return true;
  }
  return false;
}

const visitedTabs = new Set();
const isChecked = b => b.checked || b.getAttribute("aria-checked") === "true";
const optText = b => (b.labels?.[0]?.innerText || b.closest("label")?.innerText || b.parentElement?.innerText || "").trim();
function sectionLabel(el) {
  for (let n = el.parentElement, i = 0; n && i < 6; n = n.parentElement, i++) {
    const h = n.querySelector("h1,h2,h3,h4,h5,h6,legend,[class*=title i]");
    if (h && h.innerText.trim() && h.innerText.length < 100) return h.innerText.trim();
  }
  return "";
}

const isText = e => e.tagName === "TEXTAREA" || (e.tagName === "INPUT" && /^(text|number|tel|)$/.test(e.type));
const isCheckEl = e => /checkbox|switch/.test(e.type || e.getAttribute("role") || "");
function pricingGrid() {
  const heads = ["basic", "standard", "premium"].map(w => [...document.querySelectorAll("th,td,div,span,p,h3,h4,label")]
    .filter(e => visible(e) && (e.innerText || "").trim().toLowerCase() === w)
    .sort((a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top)[0]);
  if (heads.some(h => !h)) return null;
  const rects = heads.map(h => h.getBoundingClientRect());
  const cx = rects.map(r => r.left + r.width / 2), half = Math.abs(cx[1] - cx[0]) / 2;
  const extras = [...document.querySelectorAll("*")].find(e => visible(e) && /^\s*add extra services\s*$/i.test(e.innerText || ""));
  const sel = "input:not([type=hidden]):not([type=file]),textarea,select,[role=combobox],[aria-haspopup=listbox],[role=checkbox],[role=switch]";
  const cols = [[], [], []];
  for (const e of document.querySelectorAll(sel)) {
    if (!visible(e) || (extras && (extras.compareDocumentPosition(e) & Node.DOCUMENT_POSITION_FOLLOWING))) continue;
    if (e.parentElement?.closest("[role=combobox],[aria-haspopup=listbox],select")) continue;   // inner search boxes
    const b = e.getBoundingClientRect(); if (b.top < rects[0].top - 5) continue;
    const mid = b.left + b.width / 2; let k = 0, d = 1e9;
    cx.forEach((x, i) => { if (Math.abs(mid - x) < d) { d = Math.abs(mid - x); k = i; } });
    if (d < half) cols[k].push(e);
  }
  cols.forEach(col => col.sort((a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top));
  return { cols, left: cx[0] - half };
}

// ---- taxonomy scan: find the category / subcategory / service-type dropdowns on a fresh "Create a Gig" Overview page
function boxOf(leaf) {                      // the clickable dropdown box that contains a placeholder text
  let n = leaf, pointer = null;
  for (let i = 0; i < 5 && n && n !== document.body; i++, n = n.parentElement) {
    const cs = getComputedStyle(n), w = n.getBoundingClientRect().width;
    if (parseFloat(cs.borderTopWidth) > 0 && w > 120 && w < 700) return n;          // bordered box
    if (cs.cursor === "pointer" && w < 700) pointer = n;                              // outermost clickable ancestor
  }
  return pointer || leaf;
}
const PLACEHOLDER = { category: /^\s*select (a |an )?categor(y|ies)\s*$/i, subcategory: /^\s*select (a |an )?sub-?\s*categor(y|ies)\s*$/i, service: /^\s*select\b/i };
function findRole(role) {
  const tagged = document.querySelector(`[data-fgw-role="${role}"]`);
  if (tagged && document.contains(tagged) && visible(tagged)) return tagged;
  const cand = leafish().filter(e => PLACEHOLDER[role].test((e.innerText || "").trim()) && !e.closest("[data-fgw-role]"));
  if (!cand.length) return null;
  const inner = cand.filter(e => !cand.some(o => o !== e && e.contains(o)))[0];   // innermost match
  const box = boxOf(inner); box.dataset.fgwRole = role; return box;
}
function closeDropdown(el) { key(el, "Escape", 27); document.body.click(); }

// ---- text matching (no AI): used to match the pasted values against the options Fiverr really shows
const STOP = new Set(["and", "the", "of", "a", "an", "for", "to", "with", "your", "or", "in"]);
const tokensOf = s => new Set(normK(s).replace(/&/g, " and ").replace(/[^a-z0-9+#. ]/g, " ").split(" ").filter(w => w && !STOP.has(w)).map(w => w.replace(/s$/, "")));
function bestMatch(target, options, min = 0.6) {      // fuzzy: closest option to a wanted name
  const t = normK(target).replace(/&/g, "and"); let best = null, top = 0;
  for (const o of options) {
    const n = normK(o).replace(/&/g, "and"); if (n === t) return o;
    const A = tokensOf(target), B = tokensOf(o), inter = [...A].filter(w => B.has(w)).length;
    const sc = Math.max(inter / (new Set([...A, ...B]).size || 1), (n.includes(t) || t.includes(n)) ? 0.7 : 0);
    if (sc > top) { top = sc; best = o; }
  }
  return top >= min ? best : null;
}
function strictMatch(want, text) {                     // for metadata ticks: every word of the smaller side must appear in the other
  const A = tokensOf(want), B = tokensOf(text); if (!A.size || !B.size) return false;
  const [s, l] = A.size <= B.size ? [A, B] : [B, A];
  return [...s].every(w => l.has(w));
}
const altsOf = s => {
  if (Array.isArray(s)) return [...new Set(s.flatMap(altsOf))];
  const w = String(s || "").replace(/\(.*?\)/g, "").replace(/\bif available\b/gi, "").replace(/[,;\s]+$/, "").trim(); if (!w) return [];
  return [w, ...w.split(/\s*(?:\/|;|\|)\s*|\s+or\s+/i).map(x => x.trim()).filter(Boolean)].filter((x, i, a) => a.indexOf(x) === i);
};
const kindOf = label => /sub\s*-?\s*categor/i.test(label) ? "subcategory" : /categor/i.test(label) ? "category" : /service\s*type/i.test(label) ? "serviceType" : "other";
const clearDone = () => document.querySelectorAll("[data-fgw-done]").forEach(e => delete e.dataset.fgwDone);

const handlers = {

  // ---- Overview: category > subcategory > service type, taken from the paste and matched to Fiverr's real options
  async FILL_CATEGORIES({ category, subcategory, serviceType }) {
    clearDone();
    const want = { category: altsOf(category), subcategory: altsOf(subcategory), serviceType: altsOf(serviceType) };
    const steps = [];
    for (let i = 0; i < 6; i++) {
      const d = await handlers.NEXT_DROPDOWN({});
      if (!d.found) {
        if (!steps.length) return { steps, error: "I couldn't open Fiverr's category dropdown (or it is already filled).", probe: await handlers.PROBE_DROPDOWN({ role: "category" }) };
        break;
      }
      const kind = kindOf(d.label);
      if (kind === "other") { closeMenu(document.querySelector(`[data-fgw-id="${d.id}"]`) || document.body); continue; }
      let choice = null, hit = "";
      const eq = s => normK(s).replace(/&/g, "and");
      for (const w of want[kind]) { const ex = d.options.find(o => eq(o) === eq(w)); if (ex) { choice = ex; hit = w; break; } }      // exact name first
      if (!choice) for (const w of want[kind]) { choice = bestMatch(w, d.options); if (choice) { hit = w; break; } }                // then the closest
      if (!choice) {
        closeMenu(document.querySelector(`[data-fgw-id="${d.id}"]`) || document.body);
        return { steps, error: want[kind].length
          ? `Fiverr has no ${kind === "serviceType" ? "service type" : kind} matching "${want[kind][0]}". Choose it yourself on the page (options include: ${d.options.slice(0, 10).join(", ")}), then click Fill again.`
          : `Your paste has no ${kind === "serviceType" ? "service type" : kind}. Choose it yourself on the page, then click Fill again.` };
      }
      await handlers.CHOOSE_OPTION({ id: d.id, text: choice });
      steps.push({ kind, choice, wanted: hit, exact: normK(choice).replace(/&/g, "and") === normK(hit).replace(/&/g, "and") }); await sleep(700);
    }
    return { steps };
  },

  // ---- Overview: gig metadata ticks, only options that match values written in the paste
  async FILL_METADATA({ wanted, corpus }) {
    clearDone(); visitedTabs.clear();
    const W = (wanted || []).filter(Boolean), ticked = [], manual = []; let tab = "", first = true;
    const text = " " + normK(corpus || "").replace(/[^a-z0-9+#. ]/g, " ").replace(/\s+/g, " ") + " ";
    const VENDOR = new Set(["autodesk", "adobe", "microsoft", "google", "apple", "amazon", "aws", "ibm"]);
    const inText = opt => {                              // the option is written in the gig text itself
      const p = normK(opt).replace(/[^a-z0-9+#. ]/g, " ").replace(/\s+/g, " ").trim();
      if (p.length < 3 || ["other", "all", "none"].includes(p)) return false;
      if (text.includes(" " + p + " ")) return true;
      const core = p.split(" ").filter(w => !VENDOR.has(w));                       // "Autodesk AutoCAD" -> autocad
      return core.length === 1 && core[0].length >= 4 && text.includes(" " + core[0] + " ");
    };
    for (let i = 0; i < 14; i++) {
      const t = await handlers.NEXT_TAB({});                // open the next metadata tab (none = a single list)
      if (t.clicked) { tab = t.clicked; await sleep(450); } else if (!first) break;
      const c = await handlers.NEXT_CHECKS({});
      if (c.found) {
        const picks = c.options.filter(o => W.some(w => strictMatch(w, o.text)) || inText(o.text));
        if (picks.length) { await handlers.CHOOSE_CHECKS({ ids: picks.map(p => p.id) }); ticked.push(...picks.map(p => ({ text: p.text, src: W.some(w => strictMatch(w, p.text)) ? "paste" : "gig text" }))); }
        else manual.push({ tab: (tab || c.label || "a metadata group").replace(/\s*\*\s*$/, ""), required: /\*/.test(tab) });
      }
      first = false;
      if (!t.clicked) break;
    }
    return { ticked, manual };
  },

  // ---- Scope & Pricing: names, descriptions, prices, delivery, then the feature grid from each package's "Includes"
  async FILL_SCOPE_PRICING({ packages }) {
    clearDone();
    const r = await handlers.FILL_PRICING({ packages });
    const g = await handlers.PRICING_ROWS({});
    const mentions = (p, label) => [...(p.includes || []), p.name || "", p.description || ""].some(inc => strictMatch(label, inc));
    const unmatched = [], apply = [];
    for (const row of g.rows) {
      if (row.kind === "check") {
        const values = packages.map(p => mentions(p, row.label));
        if (!values.some(Boolean)) unmatched.push(row.label);
        apply.push({ ...row, values });
      } else if (/revision/i.test(row.label)) {
        const values = packages.map(p => p.revisions == null ? null : (p.revisions >= 99 ? /unlimited/i : new RegExp(`^\\s*${p.revisions}\\b`)));
        apply.push({ ...row, values });
      }
    }
    const a = await handlers.PRICING_APPLY({ rows: apply });
    return { filled: r.filled, rows: g.rows.length, changes: a.count, unmatched, min: (await handlers.MIN_PRICE({})).min };
  },

  async SET_NAMES({ names }) { KNOWN = new Set((names || []).map(normK)); return { ok: true, count: KNOWN.size }; },

  // Diagnostic: try to open a dropdown and report exactly what the page does (to send to the developer if it fails)
  async PROBE_DROPDOWN({ role }) {
    const el = findRole(role || "category");
    if (!el) return { found: false, note: "dropdown not found" };
    const outline = []; for (let n = el, i = 0; n && i < 5; n = n.parentElement, i++) { const cs = getComputedStyle(n); outline.push({ tag: n.tagName, cls: String(n.className).slice(0, 80), role: n.getAttribute("role") || "", cursor: cs.cursor, w: Math.round(n.getBoundingClientRect().width) }); }
    const tries = [];
    for (const [name, t] of [["box", el], ["first child", el.firstElementChild], ["last child", el.lastElementChild], ["parent", el.parentElement]]) {
      if (!t) continue;
      const before = new Set(leafish());
      click(t); await sleep(500);
      const fresh = leafish().filter(e => !before.has(e));
      tries.push({ target: name, newVisibleTexts: fresh.length, sample: fresh.slice(0, 6).map(e => e.innerText.trim()), knownMatches: fresh.filter(e => KNOWN.has(normK(e.innerText))).length });
      closeMenu(el); await sleep(200);
    }
    return { found: true, known: KNOWN.size, outline, tries };
  },

  // Fiverr shows "Suggested categories" (e.g. "Programming & Tech > AI Development") after you type the title
  async READ_SUGGESTIONS() {
    const head = [...document.querySelectorAll("*")].find(e => visible(e) && /^\s*suggested categories\s*:?\s*$/i.test(e.innerText || ""));
    if (!head) return { items: [] };
    let box = head.parentElement, els = [];
    for (let i = 0; i < 4 && box; i++, box = box.parentElement) {
      els = [...box.querySelectorAll("li,a,button,span,div")].filter(e => visible(e) && e.children.length <= 1 && /[>›»]/.test(e.innerText || "") && e.innerText.trim().length < 120 && !e.contains(head));
      if (els.length) break;
    }
    const byText = new Map();                              // same text on a <li> and its <a>: keep the innermost
    for (const e of els) { const t = e.innerText.trim(), cur = byText.get(t); if (!cur || cur.contains(e)) byText.set(t, e); }
    const items = [...byText].map(([text, e]) => { e.dataset.fgwSug = rnd(); return { id: e.dataset.fgwSug, text }; });
    return { items };
  },
  async CLICK_SUGGESTION({ id }) {
    const el = document.querySelector(`[data-fgw-sug="${id}"]`);
    if (!el) return { ok: false }; click(el); el.click(); return { ok: true };
  },
  async TAX_INIT() {
    document.querySelectorAll("[data-fgw-role]").forEach(e => delete e.dataset.fgwRole);
    const cat = findRole("category"), sub = findRole("subcategory");
    return { ok: !!(cat && sub), category: !!cat, subcategory: !!sub };
  },
  async TAX_LIST({ role }) {
    const el = findRole(role); if (!el) return { found: false, options: [] };
    const options = await openOptions(el);
    closeDropdown(el); await sleep(250);
    return { found: true, options };
  },
  async TAX_PICK({ role, text }) {
    const el = findRole(role); if (!el) return { ok: false };
    const ok = await choose(el, text); await sleep(300);
    return { ok };
  },
  // Clicks the page's Save & Continue / Next button. Never clicks Publish.
  async CLICK_NEXT() {
    const btns = [...document.querySelectorAll("button,a,[role=button]")].filter(b => visible(b) && !/publish/i.test(b.innerText || ""));
    let btn = btns.find(b => /^\s*(save\s*(&|and)\s*continue|continue|next)\s*$/i.test(b.innerText || ""));
    if (!btn) { const saves = btns.filter(b => /^\s*save\s*$/i.test(b.innerText || "")); btn = saves[saves.length - 1]; }  // bottom Save
    if (!btn) return { clicked: "", reason: "no Next/Save button found" };
    if (btn.disabled || btn.getAttribute("aria-disabled") === "true") return { clicked: "", reason: "the button is disabled" };
    btn.scrollIntoView({ block: "center" }); await sleep(300); btn.click();
    return { clicked: btn.innerText.trim() };
  },
  async DETECT() {   // which Fiverr gig-editor page is open?
    const t = document.body.innerText;
    const page = /set your packages|add extra services/i.test(t) ? "pricing"
      : /gig title/i.test(t) && /search tags|positive keywords/i.test(t) ? "overview"
      : /get all the information you need from buyers/i.test(t) ? "requirements"
      : /briefly describe your gig|frequently asked questions/i.test(t) ? "description"
      : /gig gallery|gig images|gig video/i.test(t) ? "gallery" : "unknown";
    return { page };
  },
  async SCAN() {   // debugging aid: describe the form controls on this page
    const fields = all('input,textarea,select,[contenteditable=true],[role=textbox],[role=combobox],[aria-haspopup=listbox]').slice(0, 80).map(el => ({
      tag: el.tagName.toLowerCase(), type: el.type || "", role: el.getAttribute("role") || "", name: el.name || "", id: el.id || "",
      placeholder: el.placeholder || "", aria: el.getAttribute("aria-label") || "", testid: el.getAttribute("data-testid") || "",
      label: labelText(el).slice(0, 80), text: (el.innerText || "").slice(0, 40)
    }));
    return { url: location.href, fields };
  },
  async FILL_OVERVIEW({ title, tags }) {
    const filled = []; visitedTabs.clear();
    const t = all("input,textarea", /title|i will/)[0];
    if (t) { setValue(t, title.replace(/^I will\s*/i, "")); filled.push("title"); }
    const tg = all("input", /tag|keyword|search term/)[0];
    if (tg) {
      tg.focus();
      for (const x of tags) { setValue(tg, x); key(tg, "Enter", 13); await sleep(250); }
      filled.push("tags");
    }
    return { filled };
  },

  // Opens the next unfilled dropdown and reports its options.
  async NEXT_DROPDOWN() {
    const txt = e => (e.innerText || e.value || "").trim();
    let el = all(COMBO).find(e => !e.dataset.fgwDone && (e.tagName === "SELECT" ? (!e.value || (e.selectedIndex <= 0 && /^\s*(select|choose|-)/i.test(e.options[0]?.text || ""))) : (!txt(e) || /^\s*(select|choose)\b/i.test(txt(e)))));
    if (!el) {
      const cands = leafish().filter(e => !e.dataset.fgwDone && !e.closest("[data-fgw-done]") && /^\s*select (a |an )?[a-z]/i.test((e.innerText || "").split("\n")[0]));
      const leaf = innermost(cands)[0];
      if (leaf) el = boxOf(leaf);
    }
    if (!el) return { found: false };
    el.dataset.fgwId = el.dataset.fgwId || rnd();
    const label = txt(el) && /^\s*select/i.test(txt(el)) ? txt(el) : rowText(el).split("\n")[0].trim();
    const options = await openOptions(el);
    el.dataset.fgwDone = "1";
    if (!options.length) return { found: false };
    return { found: true, id: el.dataset.fgwId, label, options };
  },
  async CHOOSE_OPTION({ id, text }) {
    const el = document.querySelector(`[data-fgw-id="${id}"]`);
    return { ok: !!el && await choose(el, text) };
  },

  // ---- Gig metadata: tabs with checkbox lists
  async NEXT_CHECKS() {
    const cur = all("input[type=checkbox],[role=checkbox]").filter(b => !b.dataset.fgwDone && !isChecked(b));
    const options = cur.map(b => ({ b, text: optText(b) }))
      .filter(o => o.text && o.text.length < 80 && !/agree|terms|cookie|newsletter|remember/i.test(o.text))
      .map(o => { o.b.dataset.fgwId = o.b.dataset.fgwId || rnd(); o.b.dataset.fgwDone = "1"; return { id: o.b.dataset.fgwId, text: o.text }; });
    if (!options.length) return { found: false };
    return { found: true, label: sectionLabel(cur[0]), options };
  },
  async CHOOSE_CHECKS({ ids }) {
    let n = 0;
    for (const id of ids) {
      const el = document.querySelector(`[data-fgw-id="${id}"]`);
      if (!el) continue;
      (el.labels?.[0] || el).click(); n++; await sleep(200);
    }
    return { count: n };
  },
  async NEXT_TAB() {
    const head = [...document.querySelectorAll("*")].find(e => visible(e) && /^\s*gig metadata\s*$/i.test(e.innerText || ""));
    if (!head) return { clicked: "" };
    let box = head.parentElement, tabs = [];
    for (let i = 0; i < 4 && box; i++, box = box.parentElement) {
      tabs = [...box.querySelectorAll('[role=tab],li,button,a,[class*=tab i]')]
        .filter(e => visible(e) && !e.querySelector("input") && (e.innerText || "").trim().length > 1 && e.innerText.trim().length < 40 && !visitedTabs.has(e.innerText.trim()));
      if (tabs.length) break;
    }
    const t = tabs[0];
    if (!t) return { clicked: "" };
    visitedTabs.add(t.innerText.trim()); click(t); t.click();
    return { clicked: t.innerText.trim() };
  },

  // ---- Pricing: located by geometry (3 columns under the BASIC / STANDARD / PREMIUM headers)
  async PRICING_ROWS() {
    const g = pricingGrid(); if (!g) return { rows: [] };
    const leftLabel = ctrl => {
      const b = ctrl.getBoundingClientRect(), cy = b.top + b.height / 2;
      const area = e => { const r = e.getBoundingClientRect(); return r.width * r.height; };
      const c = [...document.querySelectorAll("th,td,div,span,p,label")].filter(e => {
        if (!visible(e) || e.querySelector("input,textarea,select")) return false;
        const t = (e.innerText || "").trim(); if (t.length < 2 || t.length > 60) return false;
        const r = e.getBoundingClientRect(); return r.right <= g.left + 8 && r.top <= cy && r.bottom >= cy && r.height < 80;
      }).sort((a, b) => area(a) - area(b));
      return c[0] ? c[0].innerText.trim().split("\n")[0] : "";
    };
    const rows = [];
    for (const base of g.cols[0].filter(e => !isText(e))) {
      const by = base.getBoundingClientRect().top;
      const mates = [1, 2].map(i => g.cols[i].find(e => !isText(e) && Math.abs(e.getBoundingClientRect().top - by) < 12));
      if (mates.some(m => !m)) continue;
      const els = [base, ...mates], label = leftLabel(base);
      if (!label || /deliver|price/i.test(label) || els.some(e => e.disabled || e.getAttribute("aria-disabled") === "true")) continue;
      els.forEach(e => e.dataset.fgwId = e.dataset.fgwId || rnd());
      const isCheck = els.every(isCheckEl);
      const r = { label, kind: isCheck ? "check" : "select", ids: els.map(e => e.dataset.fgwId) };
      if (!isCheck) {
        r.options = await openOptions(els[0]);
        if (els[0].tagName !== "SELECT") { key(els[0], "Escape", 27); document.body.click(); await sleep(200); }
      }
      rows.push(r);
    }
    return { rows };
  },
  async PRICING_APPLY({ rows }) {
    let n = 0;
    for (const r of rows) for (let i = 0; i < r.ids.length; i++) {
      const el = document.querySelector(`[data-fgw-id="${r.ids[i]}"]`);
      if (!el) continue;
      if (r.kind === "check") { if (isChecked(el) !== !!r.values[i]) { (el.labels?.[0] || el).click(); n++; await sleep(150); } }
      else if (r.values[i] && await choose(el, r.values[i])) { n++; await sleep(250); }
    }
    return { count: n };
  },

  async FILL_PRICING({ packages }) {
    const g = pricingGrid(); if (!g) return { filled: [] };
    const filled = new Set(); let days = 0;
    for (let i = 0; i < 3; i++) {
      const col = g.cols[i], p = packages[i], texts = col.filter(isText);   // name, description, ..., price
      if (texts[0]) { setValue(texts[0], p.name); filled.add("names"); }
      if (texts.length >= 3) { setValue(texts[1], p.description); filled.add("descriptions"); setValue(texts[texts.length - 1], String(p.price)); filled.add("prices"); }
      const dd = col.find(e => !isText(e) && !isCheckEl(e));
      if (dd && await choose(dd, new RegExp(`^\\s*${p.days}\\s*days?\\b`, "i"))) days++;
    }
    if (days) filled.add("delivery days");
    return { filled: [...filled] };
  },

  async FILL_DESCRIPTION({ text }) {
    const el = all("textarea,[contenteditable=true],[role=textbox]", /description|describe/)[0]
      || all("textarea,[contenteditable=true]").sort((a, b) => b.clientHeight - a.clientHeight)[0];
    if (!el) return { ok: false };
    setValue(el, text); return { ok: true };
  },

  async MIN_PRICE() {   // Fiverr shows "Package prices should include predefined options at a minimum of $90"
    const m = document.body.innerText.match(/minimum of \$\s*(\d+)/i);
    return { min: m ? Number(m[1]) : 0 };
  },

  async FILL_FAQ({ items }) {
    let count = 0;
    const boxes = () => all("textarea,input:not([type]),input[type=text]").filter(e => !e.value && !/search/i.test(hint(e)));
    for (const f of items) {
      let b = boxes().filter(e => /question|answer|faq/.test(hint(e)));
      if (b.length < 2) {
        const add = [...document.querySelectorAll("button,a,[role=button]")].find(x => visible(x) && /add\s*(a\s*)?(new\s*)?(faq|question)/i.test(x.innerText));
        if (add) { add.scrollIntoView({ block: "center" }); click(add); await sleep(700); }
        b = boxes().filter(e => /question|answer|faq/.test(hint(e)));
        if (b.length < 2) b = boxes();
      }
      if (b.length < 2) break;
      const q = b.find(e => /question/.test(hint(e))) || b[0];
      const a = b.find(e => e !== q && /answer/.test(hint(e))) || b.find(e => e !== q);
      setValue(q, f.question); setValue(a, f.answer); await sleep(250);
      const confirm = [...document.querySelectorAll("button")].find(x => visible(x) && /^\s*add\s*$/i.test(x.innerText));
      if (confirm) { click(confirm); await sleep(700); }
      count++;
    }
    return { count };
  },

  async FILL_REQUIREMENTS({ items }) {
    let count = 0;
    const emptyBox = () => all("textarea,input:not([type]),input[type=text]").find(e => !e.value && !/search/i.test(hint(e)));
    for (const q of items) {
      let box = emptyBox();
      if (!box) {
        const add = [...document.querySelectorAll("button,a,[role=button]")].find(b => visible(b) && /add\s*(a\s*)?(new\s*)?question/i.test(b.innerText));
        if (add) { add.scrollIntoView({ block: "center" }); click(add); await sleep(700); box = emptyBox(); }
      }
      if (!box) break;
      setValue(box, q);
      await sleep(200);
      const confirm = [...document.querySelectorAll("button")].find(b => visible(b) && /^\s*add\s*$/i.test(b.innerText));
      if (confirm) { click(confirm); await sleep(700); }
      count++;
    }
    return { count };
  },

  // Adds the user's own saved images to the gallery's image upload box(es)
  async UPLOAD_IMAGES({ images }) {
    let n = 0; const used = new Set();
    for (const im of images) {
      const all_ = [...document.querySelectorAll("input[type=file]")].filter(i => !/video|pdf/i.test(i.accept || ""));
      const fresh = all_.filter(i => !used.has(i));
      const pool = fresh.length ? fresh : all_;
      const input = pool.find(i => /image/.test(i.accept || "")) || pool[0];
      if (!input) break;
      used.add(input);
      const blob = await (await fetch(im.dataUrl)).blob();
      const dt = new DataTransfer(); dt.items.add(new File([blob], im.name || `gig-${n + 1}.png`, { type: blob.type || im.type || "image/png" }));
      input.files = dt.files;
      input.dispatchEvent(new Event("input", { bubbles: true })); input.dispatchEvent(new Event("change", { bubbles: true }));
      n++; await sleep(2500);                       // let Fiverr finish each upload
    }
    return { count: n };
  }
};

chrome.runtime.onMessage.addListener((msg, _s, send) => {
  const h = handlers[msg.type]; if (!h) return;
  h(msg).then(send).catch(e => send({ ok: false, found: false, filled: [], count: 0, error: e.message }));
  return true;
});

})();
