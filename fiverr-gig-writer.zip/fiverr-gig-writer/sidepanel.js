const $ = id => document.getElementById(id);
const S = { titles: [], pricing: [], image: null, faq: [], hints: "" };
const KEYS = ["keywords", "notes", "scope", "days", "budget", "style", "desc", "req"];

const status = (m, ok) => { $("status").textContent = m; $("status").className = ok ? "ok" : ""; };
const kw = () => $("keywords").value.split(",").map(s => s.trim()).filter(Boolean).slice(0, 5);
const chosen = name => document.querySelector(`input[name=${name}]:checked`)?.value;
const sleep = ms => new Promise(r => setTimeout(r, ms));

async function ai(action, payload, btn) {
  if (btn) btn.disabled = true; status("Working…", true);
  try {
    const r = await chrome.runtime.sendMessage({ action, payload });
    if (!r.ok) throw new Error(r.error);
    status("Done.", true); return r.result;
  } catch (e) { status(e.message); throw e; } finally { if (btn) btn.disabled = false; }
}
async function page(type, data) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !/fiverr\.com/.test(tab.url || "")) throw new Error("This tab isn't Fiverr. Click your Fiverr gig editor tab, then try again.");
  const send = () => chrome.tabs.sendMessage(tab.id, { type, ...data });
  try { return await send(); }
  catch {
    try { await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] }); return await send(); }
    catch { throw new Error("Couldn't reach the Fiverr page. Reload the Fiverr tab and try again."); }
  }
}
const title = () => chosen("title");
const ctx = () => `${S.hints || ""}\n${$("scope").value}\n${$("desc").value}`.trim().slice(0, 1000);
const esc = x => String(x ?? "").replace(/"/g, "&quot;");

// ---- persistence / tabs / settings
chrome.storage.local.get(["geminiKey", "textModel", "form"]).then(s => {
  $("textModel").value = s.textModel || ""; $("geminiKey").value = s.geminiKey || "";
  KEYS.forEach(k => s.form?.[k] && ($(k).value = s.form[k]));
  if (!s.geminiKey) $("settings").hidden = false; counts();
});
KEYS.forEach(k => $(k).addEventListener("input", () => {
  chrome.storage.local.set({ form: Object.fromEntries(KEYS.map(x => [x, $(x).value])) }); counts();
}));
const counts = () => $("dlen").textContent = `${$("desc").value.length}/1200`;
$("gear").onclick = () => $("settings").hidden = !$("settings").hidden;
$("saveSettings").onclick = async () => {
  const msg = (t, ok) => { $("saveMsg").textContent = t; $("saveMsg").style.color = ok ? "#117a45" : "#b00"; };
  const key = $("geminiKey").value.trim();
  if (!key) return msg("Paste your key first.");
  try {
    await chrome.storage.local.set({ textModel: $("textModel").value.trim(), geminiKey: key });
    const back = await chrome.storage.local.get("geminiKey");
    if (back.geminiKey !== key) return msg("Could not save to Chrome storage. Reload the extension and try again.");
    msg("Saved. Testing key…", true);
    const r = await chrome.runtime.sendMessage({ action: "ping", payload: {} });
    msg(r.ok ? "Saved ✓ Key works." : "Saved, but the key test failed: " + r.error, r.ok);
  } catch (e) { msg("Error: " + e.message); }
};
document.querySelectorAll("#tabs button").forEach(b => b.onclick = () => {
  document.querySelectorAll("#tabs button").forEach(x => x.classList.toggle("on", x === b));
  document.querySelectorAll(".step").forEach(s => s.hidden = s.id !== "s" + b.dataset.step);
});

// ---- 1 overview
$("genTitles").onclick = async function () {
  if (kw().length < 1) return status("Enter your keywords first.");
  const r = await ai("titles", { keywords: kw(), notes: $("notes").value }, this);
  $("titles").innerHTML = r.titles.map((t, i) =>
    `<label><input type="radio" name="title" value="${t.replace(/"/g, "&quot;")}" ${i ? "" : "checked"}>${t}</label>`).join("");
  $("fillOverview").disabled = false;
};
$("fillOverview").onclick = async function () {
  this.disabled = true;
  try {
    const t = title(), tags = kw();
    const long = tags.filter(x => x.length > 20);
    const r = await page("FILL_OVERVIEW", { title: t, tags });
    if (!r.filled.length) status("Couldn't find the title/tag boxes. Click \"Scan page\" at the bottom and send me the result.");
    else status(`Filled ${r.filled.join(", ")}. Picking categories…`, true);
    for (let i = 0; i < 8; i++) {                       // category -> subcategory -> service type -> ...
      const d = await page("NEXT_DROPDOWN", {});
      if (!d.found) break;
      const p = await chrome.runtime.sendMessage({ action: "pick", payload: { label: d.label, options: d.options, title: t, keywords: tags, context: ctx() } });
      if (!p.ok) throw new Error(p.error);
      await page("CHOOSE_OPTION", { id: d.id, text: p.result.choice });
      status(`${d.label || "Dropdown"}: ${p.result.choice}`, true);
      await sleep(900);
    }
    status("Selecting gig metadata…", true);
    for (let i = 0; i < 10; i++) {                      // metadata tabs -> checkbox lists
      const c = await page("NEXT_CHECKS", {});
      if (c.found) {
        const p = await chrome.runtime.sendMessage({ action: "pickMany", payload: { label: c.label, options: c.options.map(o => o.text), title: t, keywords: tags, max: 4, context: ctx() } });
        if (!p.ok) throw new Error(p.error);
        const want = p.result.choices.map(x => x.trim().toLowerCase());
        const ids = c.options.filter(o => want.includes(o.text.trim().toLowerCase())).map(o => o.id);
        await page("CHOOSE_CHECKS", { ids });
        status(`${c.label || "Metadata"}: ${p.result.choices.join(", ")}`, true);
        await sleep(600);
      }
      const tab = await page("NEXT_TAB", {});
      if (!tab.clicked && !c.found) break;
      await sleep(800);
    }
    status("Overview filled. Check it (especially Gig metadata), then click Next on Fiverr." + (long.length ? ` Note: Fiverr tags max 20 chars: ${long.join(", ")}` : ""), true);
  } catch (e) { status(e.message); } finally { this.disabled = false; }
};

// ---- 2 pricing
$("genPricing").onclick = async function () {
  if (!title()) return status("Pick a title in step 1 first.");
  if (!$("scope").value.trim()) return status("Describe your scope first.");
  const r = await ai("pricing", { title: title(), scope: $("scope").value, days: $("days").value, budget: $("budget").value }, this);
  S.pricing = r.options;
  $("pricing").innerHTML = r.options.map((o, i) => `<label><input type="radio" name="price" value="${i}" ${i ? "" : "checked"}><b>${o.label}</b>
    <small>${["basic", "standard", "premium"].map(k => `${o[k].name}: $${o[k].price}, ${o[k].days} days\n  ${o[k].description}`).join("\n")}</small></label>`).join("");
  $("fillPricing").disabled = false;
};
$("fillPricing").onclick = async function () {
  try {
    const o = S.pricing[chosen("price")];
    let pk = [o.basic, o.standard, o.premium].map(p => ({ ...p }));
    const adj = [], min = (await page("MIN_PRICE", {})).min;          // Fiverr shows a minimum package price
    if (min) pk.forEach((p, i) => {
      const was = Number(p.price); let np = Math.max(was, min);
      if (i && np <= pk[i - 1].price) np = Math.round(pk[i - 1].price * 2.5 / 10) * 10;
      if (np !== was) adj.push(`${["Basic", "Standard", "Premium"][i]} $${was} → $${np}`); p.price = np;
    });
    const r = await page("FILL_PRICING", { packages: pk });
    status(`Filled: ${r.filled.join(", ") || "nothing found"}. Now ticking features…`, !!r.filled.length);
    const g = await page("PRICING_ROWS", {});
    if (g.rows.length) {
      const m = await chrome.runtime.sendMessage({ action: "matrix", payload: { title: title(), scope: $("scope").value, packages: pk, rows: g.rows } });
      if (!m.ok) throw new Error(m.error);
      const apply = m.result.rows.map(x => ({ ...g.rows[x.index], values: x.values })).filter(x => x.ids);
      const a = await page("PRICING_APPLY", { rows: apply });
      status(`Filled pricing and ${g.rows.length} feature rows (${a.count} changes). Check everything, then click Next on Fiverr.`, true);
      if (adj.length) status(`Filled pricing and features. Raised prices to Fiverr's $${min} minimum: ${adj.join(", ")}. Check everything.`, true);
    } else status("Pricing filled, but I couldn't find the feature tick boxes. Tick them by hand, or click Scan page and send me the result.", true);
  } catch (e) { status(e.message); }
};

// ---- 3 description
$("genDesc").onclick = async function () {
  if (!title()) return status("Pick a title in step 1 first.");
  const r = await ai("description", { title: title(), keywords: kw(), scope: $("scope").value, style: $("style").value }, this);
  $("desc").value = r.description; counts(); $("fillDesc").disabled = false;
};
$("fillDesc").onclick = async () => {
  try {
    const r = await page("FILL_DESCRIPTION", { text: $("desc").value });
    if (!r.ok) return status("Couldn't find the description box.");
    let msg = "Description filled.";
    if (S.faq?.length) { const f = await page("FILL_FAQ", { items: S.faq }); msg += ` Added ${f.count} of ${S.faq.length} FAQs.`; }
    status(msg + " Check it, then click Next on Fiverr.", true);
  } catch (e) { status(e.message); }
};

// ---- 4 requirements
$("genReq").onclick = async function () {
  if (!title()) return status("Pick a title in step 1 first.");
  const r = await ai("requirements", { title: title(), scope: $("scope").value }, this);
  $("req").value = r.requirements.join("\n"); $("fillReq").disabled = false;
};
$("fillReq").onclick = async () => {
  try { const items = $("req").value.split("\n").map(s => s.trim()).filter(Boolean);
    const r = await page("FILL_REQUIREMENTS", { items });
    status(`Filled ${r.count} of ${items.length} questions. Check it, then click Next on Fiverr.`, r.count > 0);
  } catch (e) { status(e.message); }
};

// ---- 5 gallery
// ---- 5 gallery: the user's own images, saved in this browser (IndexedDB)
const idb = () => new Promise((res, rej) => { const r = indexedDB.open("fgw", 1); r.onupgradeneeded = () => r.result.createObjectStore("imgs", { autoIncrement: true }); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
const idbAll = async () => { const db = await idb(); return new Promise(res => { const out = []; const c = db.transaction("imgs").objectStore("imgs").openCursor(); c.onsuccess = e => { const cur = e.target.result; if (cur) { out.push({ key: cur.key, blob: cur.value }); cur.continue(); } else res(out); }; }); };
const idbAdd = async blob => { const db = await idb(); return new Promise(res => { const t = db.transaction("imgs", "readwrite"); t.objectStore("imgs").add(blob); t.oncomplete = res; }); };
const idbDel = async key => { const db = await idb(); return new Promise(res => { const t = db.transaction("imgs", "readwrite"); t.objectStore("imgs").delete(key); t.oncomplete = res; }); };
const toDataUrl = blob => new Promise(res => { const r = new FileReader(); r.onload = () => res(r.result); r.readAsDataURL(blob); });

async function renderImgs() {
  const list = await idbAll();
  $("thumbs").innerHTML = "";
  list.forEach(({ key, blob }) => {
    const d = document.createElement("div"), img = document.createElement("img"), x = document.createElement("b");
    img.src = URL.createObjectURL(blob); x.textContent = "×"; x.title = "Remove";
    x.onclick = async () => { await idbDel(key); renderImgs(); };
    d.append(img, x); $("thumbs").append(d);
  });
  $("uploadImg").disabled = !list.length;
  return list;
}
async function addImages(files) {
  let have = (await idbAll()).length;
  for (const f of files) {
    if (!/^image\//.test(f.type)) continue;
    if (have >= 3) { status("Fiverr allows 3 gig images. Remove one first."); break; }
    await idbAdd(f); have++;
  }
  renderImgs();
}
$("imgFiles").onchange = async e => { await addImages([...e.target.files]); e.target.value = ""; };
document.addEventListener("paste", e => { const f = [...(e.clipboardData?.files || [])]; if (f.length) { e.preventDefault(); addImages(f); } });
renderImgs();

async function uploadSaved() {
  const list = await idbAll();
  if (!list.length) return { count: 0 };
  const images = await Promise.all(list.map(async ({ blob }, i) => ({ dataUrl: await toDataUrl(blob), name: blob.name || `gig-${i + 1}.png`, type: blob.type })));
  return page("UPLOAD_IMAGES", { images });
}
$("uploadImg").onclick = async () => {
  try { status("Uploading…", true); const r = await uploadSaved();
    status(r.count ? `Added ${r.count} image(s). Wait for Fiverr to finish uploading, check them, then click Save & Continue.` : "I couldn't find the image upload box on this page.", !!r.count);
  } catch (e) { status(e.message); }
};

$("scan").onclick = async () => {
  try { const r = await page("SCAN", {});
    await navigator.clipboard.writeText(JSON.stringify(r, null, 1));
    status(`Scanned ${r.fields.length} fields. Copied to clipboard. Paste it to me in the chat.`, true);
  } catch (e) { status(e.message); }
};

// ---- 0 paste from ChatGPT
$("parsePaste").onclick = async function () {
  const text = $("paste").value.trim();
  if (!text) return status("Paste your notes or gig text first.");
  const g = await ai("parsePaste", { text }, this);
  S.faq = g.faq || []; S.hints = g.categoryHints || "";
  const set = (id, v) => { $(id).value = v; $(id).dispatchEvent(new Event("input")); };
  const warn = [];
  if (g.title) {
    $("titles").innerHTML = `<label><input type="radio" name="title" value="${esc(g.title)}" checked>${g.title}</label>`;
    $("fillOverview").disabled = false;
    if (g.title.length > 80) warn.push("title is over 80 characters");
  }
  set("keywords", (g.tags || []).join(", "));
  set("scope", g.scope || g.description || "");
  if ((g.packages || []).length === 3) {
    const [a, b, c] = g.packages; S.pricing = [{ label: "From your paste", basic: a, standard: b, premium: c }];
    $("pricing").innerHTML = `<label><input type="radio" name="price" value="0" checked><b>From your paste</b><small>${g.packages.map(p => `${p.name}: $${p.price}, ${p.days} days\n  ${p.description}`).join("\n")}</small></label>`;
    $("fillPricing").disabled = false;
  }
  set("desc", g.description || ""); if (g.description) { $("fillDesc").disabled = false; if (g.descriptionOriginalLength) warn.push(`description was ${g.descriptionOriginalLength} characters, shortened to ${g.description.length} (Fiverr max 1200)`); }
  set("req", (g.requirements || []).join("\n")); if ((g.requirements || []).length) $("fillReq").disabled = false;
  $("pasteSummary").textContent = [
    `Title: ${g.title || "(none found)"}`, `Tags: ${(g.tags || []).join(", ") || "(none)"}`,
    `Packages: ${(g.packages || []).length === 3 ? g.packages.map(p => `${p.name} $${p.price}/${p.days}d`).join(" / ") : "(not found)"}`,
    `Description: ${(g.description || "").length} chars`, `FAQs: ${S.faq.length}`, `Requirements: ${(g.requirements || []).length}`,
    warn.length ? "⚠ " + warn.join("; ") : ""].filter(Boolean).join("\n");
  $("fillThis").disabled = false;
  S.noteText = (g.notes || []).join("; ");
  if (S.noteText) $("pasteSummary").textContent += "\nFixed for Fiverr: " + S.noteText;
  status("Gig written." + ($("auto").checked ? " Filling the current Fiverr page…" : " Open a Fiverr gig page and click Fill this Fiverr page."), true);
  if ($("auto").checked) { try { await page("DETECT", {}); $("fillThis").onclick(); } catch { status("Gig written. Open your Fiverr gig page, then click Fill this Fiverr page again."); } }
};

const FILL = { overview: "fillOverview", pricing: "fillPricing", description: "fillDesc", requirements: "fillReq" };
async function fillCurrent() {
  const { page: p } = await page("DETECT", {});
  if (p === "gallery") {
    const r = await uploadSaved();
    return { p, stop: r.count ? `Gallery: added ${r.count} of your saved image(s). Wait for the uploads to finish, check everything, then click Save & Continue and Publish yourself.` : "Reached the Gallery page. Add your images in the Gallery tab (or drag them in), then click Save & Continue yourself." };
  }
  if (!FILL[p]) return { p, stop: "I can't tell which Fiverr page this is. Open Overview, Pricing, Description or Requirements." };
  const btn = $(FILL[p]);
  if (btn.disabled) return { p, stop: `Your paste has nothing for the ${p} page.` };
  status(`Detected the ${p} page. Filling…`, true);
  await btn.onclick.call(btn);
  return { p, ok: $("status").className === "ok" };
}

$("fillThis").onclick = async () => {
  S.stop = false;
  try {
    if (!$("auto").checked) { const r = await fillCurrent(); if (r.stop) status(r.stop); return; }
    $("stopAuto").hidden = false; $("fillThis").disabled = true;
    for (let i = 0; i < 6 && !S.stop; i++) {
      const r = await fillCurrent();
      if (r.stop) return status(r.stop);
      if (!r.ok) return status(`Stopped: the ${r.p} page wasn't filled completely. Fix it, then continue.`);
      if (S.stop) break;
      await sleep(800);
      const n = await page("CLICK_NEXT", {});
      if (!n.clicked) return status(`Filled the ${r.p} page but stopped: ${n.reason}. Check the page for missing fields.`);
      let moved = false;                                   // wait for Fiverr to load the next page
      for (let t = 0; t < 20 && !S.stop; t++) { await sleep(700); try { if ((await page("DETECT", {})).page !== r.p) { moved = true; break; } } catch {} }
      if (!moved) return status(`Clicked "${n.clicked}" but Fiverr stayed on the ${r.p} page. A required field is probably missing. Check the page.`);
      await sleep(1500);
    }
    status(S.stop ? "Stopped." : "Auto-continue finished. Check the page before going on.", true);
  } catch (e) { status(e.message); }
  finally { $("stopAuto").hidden = true; $("fillThis").disabled = false; }
};
$("stopAuto").onclick = () => { S.stop = true; status("Stopping after the current step…"); };
